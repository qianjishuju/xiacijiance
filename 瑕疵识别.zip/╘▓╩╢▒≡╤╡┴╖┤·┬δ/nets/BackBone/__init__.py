from nets.BackBone.Xception import xception
from nets.BackBone.MobileNetv2 import mobilenetv2
from nets.BackBone.MobileNetv3 import mobilenetv3s,mobilenetv3l
from nets.BackBone.YOLOv8 import yolov8s,yolov8m
from nets.BackBone.HGNetv2 import hgnetv2x,hgnetv2l